package product;

/**
 * Represents weapon items in the store that provide offensive capabilities
 * Extends the base SalableProduct class with weapon-specific properties
 * @author Victor Marrujo
 * @version 3.0
 * @since 1.0
 */
public class Weapon extends SalableProduct implements Comparable<Weapon> 
{
    // Fields
    private int Damage;
    
    /**
     * Constructor for Weapon items
     * @param name The name of Weapon piece
     * @param description Description of Weapon
     * @param price Price in gold coins
     * @param quantity Available quantity in inventory
     * @param damage The damage value this Weapon provides
     */
    public Weapon(String name, String description, double price, int quantity, int damage) {
        super(name, description, price, quantity);
        Damage = damage;
    }
    
    /**
     * Gets damage rating of weapon
     * @return Damage Damage value
     */
    public int getDamage(){
        return Damage;
    }
    
    /**
     * Demonstrates weapon's offensive capability
     */
    public void swing() {
        System.out.println("Swinging " + getName() + " for " + Damage + " damage!");
    }

    /**
     * Compares weapon to another weapon based on name
     * @param other other weapon to compare to
     * @return negative integer if weapon's name comes first alphabetically,
     *         positive integer if it comes after, 0 if names are equal
     */
    @Override
    public int compareTo(Weapon other) {
        if (other == null) {
            throw new NullPointerException("Cannot compare with null");
        }
        return this.getName().compareToIgnoreCase(other.getName());
    }

    /**
     * Checks equality with another weapon based on name
     * @param obj object to compare with
     * @return true if weapons have same name, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Weapon weapon = (Weapon) obj;
        return this.getName().equalsIgnoreCase(weapon.getName());
    }
}