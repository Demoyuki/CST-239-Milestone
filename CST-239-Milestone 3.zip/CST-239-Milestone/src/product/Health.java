package product;

/**
 * Represents health restoration items in the store
 * Extends the base SalableProduct class with healing properties
 * @author Victor Marrujo
 * @version 3.0
 * @since 1.0
 **/
public class Health extends SalableProduct implements Comparable<Health> 
{
	// Fields
    private int HealingAmount;
    
    /**
     * Constructor for Health items
     * @param name Name of health item
     * @param description Description of item
     * @param price Price in gold coins
     * @param quantity Available quantity in inventory
     * @param healingAmount How much health item restores
     */
    public Health(String name, String description, double price, int quantity, int healingAmount) {
        super(name, description, price, quantity);
        HealingAmount = healingAmount;
    }
    
    /**
     * Gets healing power of item
     * @return HealingAmount amount of health restored
     */
    public int getHealingAmount() {
        return HealingAmount;
    }
    
    /**
     * Demonstrates using health item
     */
    public void use() 
    {
        System.out.println(getName() + " restores " + HealingAmount + " health points!");
    }
    
    /**
     * Compares health to another health based on name
     * @param other other health to compare to
     * @return negative integer if weapon's name comes first alphabetically,
     *         positive integer if it comes after, 0 if names are equal
     */
    @Override
    public int compareTo(Health other) {
        if (other == null) {
            throw new NullPointerException("Cannot compare with null");
        }
        return this.getName().compareToIgnoreCase(other.getName());
    }

    /**
     * Checks equality with another health based on name
     * @param obj object to compare with
     * @return true if weapons have same name, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Health health = (Health) obj;
        return this.getName().equalsIgnoreCase(health.getName());
    }
}