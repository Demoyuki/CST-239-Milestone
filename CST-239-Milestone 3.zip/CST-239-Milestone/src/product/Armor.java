package product;

/**
 * Represents armor items in the store that provide defense capabilities
 * Extends the base SalableProduct class with armor-specific properties
 * @author Victor Marrujo
 * @version 3.0
 * @since 1.0
 *
 */
public class Armor extends SalableProduct implements Comparable<Armor> 
{
    private int DefenseRating;
    
    /**
     * Constructor for Armor items
     * @param name The name of armor piece
     * @param description Description of armor
     * @param price Price in gold coins
     * @param quantity Available quantity in inventory
     * @param defenseRating defense value armor provides
     */
    public Armor(String name, String description, double price, int quantity, int defenseRating) {
        super(name, description, price, quantity);
        DefenseRating = defenseRating;
    }
    
    /**
     * Gets defense rating of armor
     * @return DefenseRating defense value
     */
    public int getDefenseRating(){
        return DefenseRating;
    }
    
    /**
     * Demonstrates armor's defensive capability
     */
    public void defend() 
    {
        System.out.println(getName() + " blocks " + DefenseRating + " damage!");
    }
    
    /**
     * Compares armor to another armor based on name
     * @param other other armor to compare to
     * @return negative integer if armor name comes first alphabetically,
     *         positive integer if it comes after, 0 if names are equal
     */
    @Override
    public int compareTo(Armor other) {
        if (other == null) {
            throw new NullPointerException("Cannot compare with null");
        }
        return this.getName().compareToIgnoreCase(other.getName());
    }

    /**
     * Checks equality with another armor based on name
     * @param obj object to compare with
     * @return true if weapons have same name, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Armor armor = (Armor) obj;
        return this.getName().equalsIgnoreCase(armor.getName());
    }
}
