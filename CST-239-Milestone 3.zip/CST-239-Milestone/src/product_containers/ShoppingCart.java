package product_containers;

import java.util.ArrayList;
import java.util.List;
import product.SalableProduct;

/**
 * Represents a shopping cart for storing products before purchase
 * @author Victor Marrujo
 * @version 3.1
 * @since 1.0
 */
public class ShoppingCart 
{
    // Fields
    private List<SalableProduct> cartItems;

    /**
     * ShoppingCart Constructor - initializes empty cart
     */
    public ShoppingCart() 
    {
        cartItems = new ArrayList<>();
    }

    /**
     * Adds product to cart or updates quantity if already exists
     * @param product Product to add
     */
    public void addProduct(SalableProduct product) {
        // Check if product already exists in cart (case-insensitive)
        for (SalableProduct cartItem : cartItems) {
            if (cartItem.getName().equalsIgnoreCase(product.getName())) {
                // Update quantity if product exists
                cartItem.setQuantity(cartItem.getQuantity() + product.getQuantity());
                return;
            }
        }
        // Add new product if not already in cart
        cartItems.add(product.clone());
        sortCartItems(); // Maintain sorted order
    }


    /**
     * Removes product from cart
     * @param product Product to remove
     * @return true if removal was successful, false otherwise
     */
    public boolean removeProduct(SalableProduct product) 
    {
        return cartItems.remove(product);
    }
    
    /**
     * Empties the cart completely
     */
    public void clear() {
        cartItems.clear();
    }

    /**
     * Retrieves list of all products in cart
     * @return List of products in cart
     */
    public List<SalableProduct> getCartItems() 
    {
        return new ArrayList<>(cartItems); // Return copy to prevent external modification
    }
    
    /**
     * Calculates total price of all items in cart
     * @return Total price as double
     */
    public double calculateTotal() {
        double total = 0;
        for (SalableProduct item : cartItems) {
            total += item.getPrice() * item.getQuantity();
        }
        return total;
    }
    
    /**
     * Displays formatted cart contents to console
     */
    public void displayCart() {
        System.out.println("\n=== YOUR SHOPPING CART ===");
        
        if (cartItems.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        
        double total = 0;
        for (int i = 0; i < cartItems.size(); i++) {
            SalableProduct item = cartItems.get(i);
            double itemTotal = item.getPrice() * item.getQuantity();
            System.out.printf("%d. %-20s $%-8.2f x %-3d = $%.2f\n",
                i + 1,
                item.getName(),
                item.getPrice(),
                item.getQuantity(),
                itemTotal);
            total += itemTotal;
        }
        
        System.out.println("----------------------------");
        System.out.printf("TOTAL: $%.2f\n", total);
    }
    
    /**
     * Sorts cart items alphabetically by product name (case-insensitive)
     */
    public void sortCartItems() {
        cartItems.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
    }
}