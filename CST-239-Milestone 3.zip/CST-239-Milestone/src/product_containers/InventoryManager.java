package product_containers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import product.Armor;
import product.Health;
import product.SalableProduct;
import product.Weapon;

/**
 * Manages the inventory of products
 * @author Victor Marrujo
 * @version 3.1
 * @since 1.0
 */
public class InventoryManager 
{
    // Fields
    private List<SalableProduct> products;

    /**
     * InventoryManager Constructor - initializes empty inventory
     */
    public InventoryManager() 
    {
        products = new ArrayList<>();
    }

    /**
     * Adds product to inventory
     * @param product Product to add
     */
    public void addProduct(SalableProduct product) {
        // Check if product already exists
        for (SalableProduct p : products) {
            if (p.getName().equalsIgnoreCase(product.getName())) {
                p.setQuantity(p.getQuantity() + product.getQuantity());
                return;
            }
        }
        products.add(product);
    }

    /**
     * Removes product from inventory
     * @param product Product to remove
     * @return true if removal was successful, false otherwise
     */
    public boolean removeProduct(SalableProduct product) {
        return products.remove(product);
    }

    /**
     * Retrieves list of all products in inventory
     * @return List of products
     */
    public List<SalableProduct> getProducts() {
        return new ArrayList<>(products); // Return copy to prevent external modification
    }
    
    /**
     * Finds a product in inventory by name
     * @param name Name of product to find
     * @return The product if found, null otherwise
     */
    public SalableProduct findProductByName(String name) {
        for (SalableProduct product : products) {
            if (product.getName().equalsIgnoreCase(name)) {
                return product;
            }
        }
        return null;
    }

    /**
     * Displays a single category of products
     * @param products List of products in the category
     */
    private void displayCategory(List<? extends SalableProduct> products) {
        for (int i = 0; i < products.size(); i++) {
            SalableProduct product = products.get(i);
            String stockStatus = product.getQuantity() <= 0 ? " (OUT OF STOCK)" : "";
            System.out.printf("%d. %-20s %-40s $%-8.2f Qty: %d%s\n",
                i + 1,
                product.getName(),
                product.getDescription(),
                product.getPrice(),
                product.getQuantity(),
                stockStatus);
            
            displayProductDetails(product);
        }
    }

    private void displayProductDetails(SalableProduct product) {
        if (product instanceof Weapon) {
            System.out.println("   Damage: " + ((Weapon)product).getDamage());
        } else if (product instanceof Armor) {
            System.out.println("   Defense: " + ((Armor)product).getDefenseRating());
        } else if (product instanceof Health) {
            System.out.println("   Healing: " + ((Health)product).getHealingAmount());
        }
    }
    
    /**
     * Sorts inventory items alphabetically by product name (case-insensitive)
     */
    public void sortInventory() {
        Collections.sort(products, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
    }
    
    /**
     * Gets products sorted by name (case-insensitive)
     * @return List of sorted products
     */
    public List<SalableProduct> getSortedProducts() {
        List<SalableProduct> sorted = new ArrayList<>(products);
        sorted.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return sorted;
    }

    /**
     * Displays inventory grouped by sorted categories
     */
    public void displayInventory() {
        List<Weapon> weapons = getSortedWeapons();
        List<Armor> armors = getSortedArmors();
        List<Health> healthItems = getSortedHealthItems();

        System.out.println("\n=== STORE INVENTORY ===");

        if (!weapons.isEmpty()) {
            System.out.println("\n=== WEAPONS ===");
            displayCategory(weapons);
        }

        if (!armors.isEmpty()) {
            System.out.println("\n=== ARMOR ===");
            displayCategory(armors);
        }

        if (!healthItems.isEmpty()) {
            System.out.println("\n=== HEALTH ITEMS ===");
            displayCategory(healthItems);
        }

        if (weapons.isEmpty() && armors.isEmpty() && healthItems.isEmpty()) {
            System.out.println("No items available in inventory.");
        }
    }
    
    /**
     * Gets sorted weapons
     * @return sorted weapons
     */
    public List<Weapon> getSortedWeapons() {
        List<Weapon> weapons = new ArrayList<>();
        for (SalableProduct p : products) {
            if (p instanceof Weapon) weapons.add((Weapon)p);
        }
        Collections.sort(weapons);
        return weapons;
    }

    /**
     * Gets sorted armors
     * @return sorted armors
     */
    public List<Armor> getSortedArmors() {
        List<Armor> armors = new ArrayList<>();
        for (SalableProduct p : products) {
            if (p instanceof Armor) armors.add((Armor)p);
        }
        Collections.sort(armors);
        return armors;
    }
    
    /**
     * Gets sorted Health items
     * @return sorted Health items
     */
    public List<Health> getSortedHealthItems() {
        List<Health> healthItems = new ArrayList<>();
        for (SalableProduct p : products) {
            if (p instanceof Health) healthItems.add((Health)p);
        }
        Collections.sort(healthItems);
        return healthItems;
    }
    
    
    /**
     * Displays inventory with continuous numbering across categories
     */
    public void displayInventoryWithContinuousNumbers() {
        List<SalableProduct> allProducts = new ArrayList<>();
        allProducts.addAll(getSortedWeapons());
        allProducts.addAll(getSortedArmors());
        allProducts.addAll(getSortedHealthItems());

        System.out.println("\n=== STORE INVENTORY ===");

        if (allProducts.isEmpty()) {
            System.out.println("No items available in inventory.");
            return;
        }

        // Track current category for section headers
        String currentCategory = "";
        
        for (int i = 0; i < allProducts.size(); i++) {
            SalableProduct product = allProducts.get(i);
            String productCategory = getProductCategory(product);
            
            // Print category header when category changes
            if (!productCategory.equals(currentCategory)) {
                System.out.println("\n=== " + productCategory.toUpperCase() + " ===");
                currentCategory = productCategory;
            }
            
            String stockStatus = product.getQuantity() <= 0 ? " (OUT OF STOCK)" : "";
            System.out.printf("%d. %-20s %-40s $%-8.2f Qty: %d%s\n",
                i + 1,  // Continuous numbering
                product.getName(),
                product.getDescription(),
                product.getPrice(),
                product.getQuantity(),
                stockStatus);
            
            displayProductDetails(product);
        }
    }
    /**
     * Gets the type of the object so it can be sorted into the proper array
     * @param product product to be sorted
     * @return Collection in which the item belongs
     */
    private String getProductCategory(SalableProduct product) {
        if (product instanceof Weapon) return "WEAPONS";
        if (product instanceof Armor) return "ARMOR";
        if (product instanceof Health) return "HEALTH ITEMS";
        return "OTHER";
    }

	/**
	 * Gets all products sorted by category and name
	 * @return array with all sorted items
	 */
    public List<SalableProduct> getAllSortedProducts() {
        List<SalableProduct> allProducts = new ArrayList<>();
        allProducts.addAll(getSortedWeapons());
        allProducts.addAll(getSortedArmors());
        allProducts.addAll(getSortedHealthItems());
        return allProducts;
    }
}