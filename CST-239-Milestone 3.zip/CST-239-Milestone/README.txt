Loom recordings:
1.-
https://www.loom.com/share/89d3dff2a370450aa5b14c9d3ed9f413?sid=b6d7fd95-b2f4-4e24-9edd-a73df873a4ac
2.-
https://www.loom.com/share/8fe717e2aeec4cf18480af777976dcd3?sid=b9de43d3-5fd0-4da2-9fb5-fd4f73574f6d