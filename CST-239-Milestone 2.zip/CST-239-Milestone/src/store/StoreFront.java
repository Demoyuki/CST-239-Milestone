package store;

import java.util.Scanner;
import java.util.List;

import product.SalableProduct;
import product.Armor;
import product.Health;
import product.Weapon;
import product_containers.InventoryManager;
import product_containers.ShoppingCart;

/**
 * Represents store front that interacts with inventory and shopping cart
 * @author Victor Marrujo
 * @version 2.0
 * @since 1.0
 */
public class StoreFront
{
	// Fields
    private InventoryManager inventory;
    private ShoppingCart cart;
    private Scanner scanner;

    /**
     * SotreFront Constructor
     */
    public StoreFront() 
    {
        inventory = new InventoryManager();
        cart = new ShoppingCart();
        scanner = new Scanner(System.in);
        initializeInventory();
    }
    
    /**
     * Main method to launch the application
     * @param args arguments for main
     */
    public static void main(String[] args) {
        StoreFront store = new StoreFront();
        store.run();
    }

    /**
     * Populates the store with initial inventory
     */
    private void initializeInventory() 
    {
        // Weapons
        inventory.addProduct(new Weapon("Steel Sword", "Sharp double-edged sword", 150.0, 10, 20));
        inventory.addProduct(new Weapon("Wooden Bow", "Hunting bow with arrows", 90.0, 5, 15));
        
        // Armor
        inventory.addProduct(new Armor("Chainmail", "Interlocking metal rings", 200.0, 7, 30));
        inventory.addProduct(new Armor("Leather Armor", "Treated animal hide", 120.0, 12, 15));
        
        // Health
        inventory.addProduct(new Health("Health Potion", "Restores 50 HP", 50.0, 20, 50));
        inventory.addProduct(new Health("Lesser Health Potion", "Restores 20 HP", 20.0, 20, 50));
    }

    /**
     * Main application loop
     */
    public void run() 
    {
        displayWelcome();
        
        while (true) 
        {
            displayMainMenu();
            int choice = getMenuChoice(1, 6);
            
            switch (choice) 
            {
                case 1:
                	inventory.displayInventory();
                    break;
                case 2:
                	grabProduct();
                    break;
                case 3:
                    cancelPurchase();
                case 4:
                    cart.displayCart();
                    break;
                case 5:
                	purchaseProduct();
                    break;
                case 6:
                    System.out.println("Thank you for shopping with us!");
                    return;
                default:
                    System.out.println("Invalid selection. Please try again.");
            }
        }
    }

    /**
     * Displays welcome message
     */
    private void displayWelcome() 
    {
        System.out.println("\n=== WELCOME TO THE YE'OLD ITEM SHOP ===");
        System.out.println("Your one-stop shop for all your adventuring needs!\n");
    }

    /**
     * Displays the main menu options
     */
    private void displayMainMenu() 
    {
        System.out.println("\nMAIN MENU");
        System.out.println("1. View Store Inventory");
        System.out.println("2. Grab Item");
        System.out.println("3. Put Item Back");
        System.out.println("4. View Shopping Cart");
        System.out.println("5. Complete Purchase");
        System.out.println("6. Exit Store");
        System.out.print("Please enter your choice (1-6): ");
    }

    /**
     * Gets and validates menu choice
     */
    private int getMenuChoice(int min, int max) {
        while (true) 
        {
            try 
            {
                int choice = Integer.parseInt(scanner.nextLine());
                if (choice >= min && choice <= max) 
                {
                    return choice;
                }
                System.out.print("Invalid input. Please enter a number between " + min + "-" + max + ": ");
            } catch (NumberFormatException e) 
            {
                System.out.print("Invalid input. Please enter a number: ");
            }
        }
    }
    
    /**
     * Displays current inventory for user choice
     */
    private void viewInventory() 
    {
        System.out.println("\n=== STORE INVENTORY ===");
        List<SalableProduct> products = inventory.getProducts();
        if (products.isEmpty()) 
        {
            System.out.println("No items available in inventory.");
            return;
        }
        
        for (int i = 0; i < products.size(); i++) {
            SalableProduct product = products.get(i);
            System.out.printf("%d. %-20s %-40s $%-8.2f Qty: %d\n",
                i + 1,
                product.getName(),
                product.getDescription(),
                product.getPrice(),
                product.getQuantity());
        }
    }
    
    /**
     * Move product from inventory to cart.
     */
    public void grabProduct()
    {
        viewInventory();
        List<SalableProduct> products = inventory.getProducts();
        
        if (products.isEmpty()) 
        {
            System.out.println("No items available to grab.");
            return;
        }
        
        System.out.print("\nEnter the number of the item you want to grab: ");
        int itemNumber = getMenuChoice(1, products.size()) - 1;
        
        SalableProduct product = products.get(itemNumber);
        
        System.out.print("Enter quantity to grab (Available: " + product.getQuantity() + "): ");
        int quantity = getMenuChoice(1, product.getQuantity());
        
        SalableProduct grabbedItem = product.clone();
        grabbedItem.setQuantity(quantity);
        cart.addProduct(grabbedItem);
        product.setQuantity(product.getQuantity() - quantity);
        
        System.out.printf("\nSuccessfully grabbed %d x %s (Added to cart)\n",
            quantity, product.getName());
    }
    /**
     * Move product back to the inventory.
     */
    public void cancelPurchase() 
    {
    	List<SalableProduct> cartItems = cart.getCartItems();
        if (cartItems.isEmpty()) 
        {
            System.out.println("Your cart is empty. Nothing to put back.");
            return;
        }
        
        System.out.println("\n=== ITEMS IN YOUR CART ===");
        for (int i = 0; i < cartItems.size(); i++) 
        {
            SalableProduct item = cartItems.get(i);
            System.out.printf("%d. %-20s Qty: %d\n",
                i + 1,
                item.getName(),
                item.getQuantity());
        }
        
        System.out.print("\nEnter the number of the item to put back: ");
        int itemNumber = getMenuChoice(1, cartItems.size()) - 1;
        SalableProduct item = cartItems.get(itemNumber);
        
        System.out.print("Enter quantity to put back (In cart: " + item.getQuantity() + "): ");
        int quantity = getMenuChoice(1, item.getQuantity());
        
        // Find matching product in inventory
        for (SalableProduct inventoryItem : inventory.getProducts()) 
        {
            if (inventoryItem.getName().equals(item.getName())) 
            {
                inventoryItem.setQuantity(inventoryItem.getQuantity() + quantity);
                break;
            }
        }
        
        if (quantity == item.getQuantity()) 
        {
            cart.removeProduct(item);
        } else {
            item.setQuantity(item.getQuantity() - quantity);
        }
        
        System.out.printf("\nSuccessfully put back %d x %s\n",
            quantity, item.getName());
    }
    
    /**
     * Finalizes purchase by removing items from cart, calculating the total, and thanking the user
     */
    public void purchaseProduct() 
    {
    	 List<SalableProduct> cartItems = cart.getCartItems();
         if (cartItems.isEmpty()) 
         {
             System.out.println("Your cart is empty. Nothing to purchase.");
             return;
         }
         
         System.out.println("\n=== PURCHASE SUMMARY ===");
         double total = 0;
         for (SalableProduct item : cartItems) 
         {
             double itemTotal = item.getPrice() * item.getQuantity();
             System.out.printf("%-20s %-8.2f x %d = $%.2f\n",
                 item.getName(),
                 item.getPrice(),
                 item.getQuantity(),
                 itemTotal);
             total += itemTotal;
         }
         
         System.out.printf("\nTOTAL: $%.2f\n", total);
         System.out.print("Confirm purchase (Y/N)? ");
         String confirmation = scanner.nextLine();
         
         if (confirmation.equalsIgnoreCase("Y")) 
         {
             cart.getCartItems().clear();
             System.out.println("Purchase completed! Thank you for shopping with us!");
         } else {
             System.out.println("Purchase canceled.");
         }
     }
}