package product_containers;

import java.util.ArrayList;
import java.util.List;

import product.SalableProduct;

/**
 * Represents a shopping cart
 * @author Victor Marrujo
 * @version 2.0
 * @since 1.0
 */

public class ShoppingCart 
{
	// Fields
    private List<SalableProduct> cartItems;

    /**
     *  ShoppingCart Constructor
     */
    public ShoppingCart() 
    {
        cartItems = new ArrayList<>();
    }

    /**
     * Adds product to cart
     *
     * @param product Product to add
     */
    public void addProduct(SalableProduct product) 
    {
        cartItems.add(product);
    }

    /**
     * Removes product from cart
     *
     * @param product Product to remove
     */
    public void removeProduct(SalableProduct product) 
    {
        cartItems.remove(product);
    }
    
    

    /**
     * Retrieves list of products in cart
     *
     * @return cartItems List of products
     */
    public List<SalableProduct> getCartItems() 
    {
        return cartItems;
    }
    
    /**
     * Displays formatted cart contents to console
     */
    public void displayCart() 
    {
        System.out.println("\n=== YOUR SHOPPING CART ===");
        
        if (cartItems.isEmpty()) 
        {
            System.out.println("Your cart is empty.");
            return;
        }
        
        double total = 0;
        for (int i = 0; i < cartItems.size(); i++) 
        {
            SalableProduct item = cartItems.get(i);
            double itemTotal = item.getPrice() * item.getQuantity();
            System.out.printf("%d. %-20s %-8.2f x %d = $%.2f\n",
                i + 1,
                item.getName(),
                item.getPrice(),
                item.getQuantity(),
                itemTotal);
            total += itemTotal;
        }
        
        System.out.printf("\nTOTAL: $%.2f\n", total);
    }
}