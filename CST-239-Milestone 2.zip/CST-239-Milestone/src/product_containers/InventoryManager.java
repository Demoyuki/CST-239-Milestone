package product_containers;

import java.util.ArrayList;
import java.util.List;

import product.Armor;
import product.Health;
import product.SalableProduct;
import product.Weapon;

/**
 * Manages the inventory of products
 * @author Victor Marrujo
 * @version 2.0
 * @since 1.0
 */
public class InventoryManager 
{
	// Fields
    private List<SalableProduct> products;

    /**
     *  InventoryManager Constructor
     */
    public InventoryManager() 
    {
        products = new ArrayList<>();
    }

    /**
     * Adds product to inventory
     *
     * @param product Product to add
     */
    public void addProduct(SalableProduct product) {
        products.add(product);
    }

    /**
     * Removes product from inventory
     *
     * @param product Product to remove
     */
    public void removeProduct(SalableProduct product) {
        products.remove(product);
    }

    /**
     * Retrieves list of products in inventory
     *
     * @return products List of products
     */
    public List<SalableProduct> getProducts() {
        return products;
    }
    
    /**
     * Displays all available inventory
     */
    public void displayInventory() 
    {
        System.out.println("\n=== STORE INVENTORY ===");
        
        if (products.isEmpty()) {
            System.out.println("No items available in inventory.");
            return;
        }
        
        for (int i = 0; i < products.size(); i++) {
            SalableProduct product = products.get(i);
            System.out.printf("%d. %-20s %-40s $%-8.2f Qty: %d\n",
                i + 1,
                product.getName(),
                product.getDescription(),
                product.getPrice(),
                product.getQuantity());
            
            displayProductDetails(product);
        }
    }

    /**
     * Displays type-specific product details
     */
    private void displayProductDetails(SalableProduct product) 
    {
        if (product instanceof Weapon) 
        {
            System.out.println("   Damage: " + ((Weapon)product).getDamage());
        } else if (product instanceof Armor) {
            System.out.println("   Defense: " + ((Armor)product).getDefenseRating());
        } else if (product instanceof Health) {
            System.out.println("   Healing: " + ((Health)product).getHealingAmount());
        }
    }
}
