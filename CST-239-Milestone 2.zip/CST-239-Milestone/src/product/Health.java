package product;

/**
 * Represents health restoration items in the store
 * Extends the base SalableProduct class with healing properties
 * @author Victor Marrujo
 * @version 1.0
 * @since 1.0
 **/
public class Health extends SalableProduct 
{
	// Fields
    private int HealingAmount;
    
    /**
     * Constructor for Health items
     * @param name Name of health item
     * @param description Description of item
     * @param price Price in gold coins
     * @param quantity Available quantity in inventory
     * @param healingAmount How much health item restores
     */
    public Health(String name, String description, double price, int quantity, int healingAmount) {
        super(name, description, price, quantity);
        HealingAmount = healingAmount;
    }
    
    /**
     * Gets healing power of item
     * @return HealingAmount amount of health restored
     */
    public int getHealingAmount() {
        return HealingAmount;
    }
    
    /**
     * Demonstrates using health item
     */
    public void use() 
    {
        System.out.println(getName() + " restores " + HealingAmount + " health points!");
    }
}