package product;

/**
 * Represents armor items in the store that provide defense capabilities
 * Extends the base SalableProduct class with armor-specific properties
 * @author Victor Marrujo
 * @version 1.0
 * @since 1.0
 *
 */
public class Armor extends SalableProduct 
{
    private int DefenseRating;
    
    /**
     * Constructor for Armor items
     * @param name The name of armor piece
     * @param description Description of armor
     * @param price Price in gold coins
     * @param quantity Available quantity in inventory
     * @param defenseRating defense value armor provides
     */
    public Armor(String name, String description, double price, int quantity, int defenseRating) {
        super(name, description, price, quantity);
        DefenseRating = defenseRating;
    }
    
    /**
     * Gets defense rating of armor
     * @return DefenseRating defense value
     */
    public int getDefenseRating(){
        return DefenseRating;
    }
    
    /**
     * Demonstrates armor's defensive capability
     */
    public void defend() 
    {
        System.out.println(getName() + " blocks " + DefenseRating + " damage!");
    }
}
