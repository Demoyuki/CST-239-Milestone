Loom recordings:
1.-
https://www.loom.com/share/93d66e8b0d07461abc0c41f31f4c4802?sid=9020217d-4e24-48b1-9cd5-9366e7ce8625
2.-
https://www.loom.com/share/9d95d41cee6d4f6c9bb8ead86915a601?sid=54c36e63-82c0-4f52-8367-092a148951b9